
package com.code.dao.read;
import java.util.*;
import com.code.config.mybatis.ReadMapper;
import com.code.domain.Shop;
import java.util.List;

/**
 * <p> Mapper Class</p>
 *
 * @author majian
 * 
 */
public interface ReadShopMapper extends ReadMapper<Shop>{

}
