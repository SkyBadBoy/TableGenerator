
package com.code.dao.write;
import java.util.*;
import com.code.config.mybatis.MyMapper;
import com.code.domain.Specification;

/**
 * <p> Mapper Class</p>
 *
 * @author majian
 * 
 */
public interface SpecificationMapper extends MyMapper<Specification>{

}
