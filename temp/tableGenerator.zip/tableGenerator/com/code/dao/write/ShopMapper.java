
package com.code.dao.write;
import java.util.*;
import com.code.config.mybatis.MyMapper;
import com.code.domain.Shop;

/**
 * <p> Mapper Class</p>
 *
 * @author majian
 * 
 */
public interface ShopMapper extends MyMapper<Shop>{

}
